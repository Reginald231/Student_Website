print("""
Hello CS4720, I am Reginald Long, and I am a fourth year CS major at Kennesaw State University.
My typical hobbies are playing video games, programming, watching TV, or streaming shows.
I hope that I learn a lot about internet programming in this class as I've been wanting to find out how to link the
material I learn here with other programming languages like Java or Python.""")